import Vue from 'vue'
import App from './App.vue'
// 引入文件包  import  自定义名字  from  文件地址(如果文件在node_modules中出现过，直接书写文件名字即可)
import VueRouter from 'vue-router'
// 配置vue可以使用vuerouter
Vue.use(VueRouter)
// 引入页面
import first from './components/first.vue'
import type from './components/type.vue'
import index from './components/index.vue'
import my from './components/my.vue'
import car from './components/car.vue'
// 配置路由
var router=new VueRouter({
    routes:[
        {
            path:'/',
            component:first,
            children:[
                {
                    path:'/index',
                    component:index
                },
                {
                    path:'/type',
                    component:type
                }
            ],
            redirect:'/index'
        },
        {
            path:'/my',
            component:my
        },
        {
            path:'/car',
            component:car
        }
    ]
})
Vue.config.productionTip = false
new Vue({
  render: h => h(App),
  router
  
}).$mount('#app')

// 实现京东 (首页  分类 购物车 未登录) 四个功能