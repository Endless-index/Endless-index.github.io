<template>
    <main>
        <router-view></router-view>
        <ul>
            <li>
                <router-link to="/index">首页</router-link>
            </li>
            <li>
                <router-link to="/type">分类</router-link>
            </li>
            <li>
                <router-link to="/car">购物车</router-link>
            </li>
            <li>
                <router-link to="/my">我的</router-link>
            </li>
        </ul>
    </main>
</template>

// scoped限制在当前vue有效
<style scoped>
/* 移动端布局  宽度百分比，高度自适应 ，左右两边留白固定20px */
/* 宽度百分比，参照物是父级 */
ul{
    position: fixed;
    bottom:0px;
    left:0px;
    width:100%
}
ul li{
    width:25%;
    float: left;
    text-align: center;
    margin-bottom: 20px;
}
ul a{
    color:#9d9d9d;
    text-decoration: none;
    font-size: 14px;
}
ul li .router-link-exact-active {
    color:#f31106
}
</style>

// colorcop吸颜色的工具