<template>
    <h1>这是购物车</h1>
</template>