1、vue项目运行的时候，不能关闭命令行
node_modules安装包 各种依赖文件
public放置公共文件 index.html 
src放置源文件
assets放置静态资源  不变的css  js images
components放置组件  之前讲的每一个组件，现在都是一个vue文件
App.vue组件入口放置的内容就是之前在html的app内部放置的内容
main.js整个项目入口

package.json包管理文件


下载包，  npm i  vue-router@版本号 -S

内置的没有vue-router 所以需要自己下载  npm  i  vue-router@3  -S


vetur扩展该插件，实现提示功能
免费吸取颜色  https://colorcop.en.softonic.com/
测量工具  https://fancynode.com.cn/pxcook


10vw和当前窗口一样宽，100vh和当前窗口一样高